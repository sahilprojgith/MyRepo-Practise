package com.telusko.SpringJDBCeg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJdbCegApplicationTests {

	@Test
	void contextLoads() {
	}

}
