package com.telusko.SpringJDBCeg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJdbCegApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJdbCegApplication.class, args);
	}

}
